// raisehan -- pointer to raise handler
#include <exception>
_X_STD_BEGIN

/*** START TI REPLACE ***/
_DATA_ACCESS _Prhand _Raise_handler = 0;	// define raise handler pointer
/*** END TI REPLACE ***/

_X_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
